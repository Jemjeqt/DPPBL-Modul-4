import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:tubes_peukanrumoh_707012400102/navigation/app_router.dart';
import 'package:tubes_peukanrumoh_707012400102/navigation/app_routes.dart';
import 'package:tubes_peukanrumoh_707012400102/pages/main_shell_page.dart';

void main() {
  Future<void> pumpToShell(WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        initialRoute: AppRoutes.splash,
        onGenerateRoute: AppRouter.onGenerateRoute,
        onUnknownRoute: AppRouter.onUnknownRoute,
      ),
    );
    // Lewati splash (1,6 detik) dan biarkan navigasi selesai.
    await tester.pump(const Duration(seconds: 2));
    await tester.pumpAndSettle();
  }

  /// Isi email/password dummy lalu tekan tombol Masuk.
  Future<void> loginAsDemoUser(WidgetTester tester) async {
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Email'),
      'demo@contoh.id',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Password'),
      'rahasia',
    );
    await tester.tap(find.text('Masuk'));
    await tester.pumpAndSettle();
  }

  void useNarrowScreen(WidgetTester tester) {
    tester.view.physicalSize = const Size(1080, 1920);
    tester.view.devicePixelRatio = 3.0; // 360x640 dp: sempit
    addTearDown(tester.view.reset);
  }

  void useWideScreen(WidgetTester tester) {
    tester.view.physicalSize = const Size(2400, 1350);
    tester.view.devicePixelRatio = 2.0; // 1200x675 dp: lebar
    addTearDown(tester.view.reset);
  }

  testWidgets('splash pindah ke login via named route', (tester) async {
    await pumpToShell(tester);
    expect(find.text('Masuk ke Peukan Rumoh'), findsOneWidget);
  });

  testWidgets('register pop dengan data, login mengisi email', (tester) async {
    await pumpToShell(tester);

    await tester.tap(find.text('Daftar akun baru'));
    await tester.pumpAndSettle();

    await tester.enterText(
      find.widgetWithText(TextFormField, 'Nama lengkap'),
      'Budi Aceh',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Email'),
      'budi@contoh.id',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Nomor HP'),
      '081234567890',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Alamat pengiriman'),
      'Jl. Uji No. 1',
    );
    await tester.enterText(
      find.widgetWithText(TextFormField, 'Password'),
      'rahasia',
    );
    await tester.tap(find.text('Daftar'));
    await tester.pumpAndSettle();

    expect(find.text('budi@contoh.id'), findsOneWidget);
    expect(find.textContaining('Budi Aceh'), findsOneWidget);
  });

  testWidgets('login masuk shell: NavigationBar tampil di layar sempit',
      (tester) async {
    useNarrowScreen(tester);

    await pumpToShell(tester);
    await loginAsDemoUser(tester);

    expect(find.byType(NavigationBar), findsOneWidget);
    expect(find.byType(NavigationRail), findsNothing);
    expect(find.text('Beranda'), findsWidgets);

    // Tab navigation via NavigationBar.
    await tester.tap(find.text('Pesanan'));
    await tester.pumpAndSettle();
    expect(find.byType(TabBar), findsOneWidget);
  });

  testWidgets('NavigationRail muncul di layar lebar', (tester) async {
    useWideScreen(tester);

    await pumpToShell(tester);
    await loginAsDemoUser(tester);

    expect(find.byType(NavigationRail), findsOneWidget);
    expect(find.byType(NavigationBar), findsNothing);
  });

  testWidgets('drawer berisi item yang semua routenya terdaftar',
      (tester) async {
    useNarrowScreen(tester);

    await pumpToShell(tester);
    await loginAsDemoUser(tester);

    await tester.tap(find.byIcon(Icons.menu));
    await tester.pumpAndSettle();

    expect(find.text('Riwayat Pesanan'), findsOneWidget);
    expect(find.text('Tentang Aplikasi'), findsOneWidget);

    await tester.tap(find.text('Tentang Aplikasi'));
    await tester.pumpAndSettle();
    expect(find.text('Demo navigasi tugas DPPB'), findsOneWidget);
  });

  testWidgets('route tidak dikenal jatuh ke halaman not-found',
      (tester) async {
    await pumpToShell(tester);

    // Nama salah tulis seperti pada soal.
    final navigator = tester.element(find.byType(Navigator));
    // ignore: unawaited_futures
    Navigator.of(navigator).pushNamed('/prodak');
    await tester.pumpAndSettle();

    expect(find.text('Halaman tidak ditemukan'), findsOneWidget);
    expect(find.textContaining('/prodak'), findsOneWidget);
  });

  testWidgets('route /main langsung memuat MainShellPage', (tester) async {
    useNarrowScreen(tester);
    await tester.pumpWidget(
      MaterialApp(
        initialRoute: AppRoutes.main,
        onGenerateRoute: AppRouter.onGenerateRoute,
        onUnknownRoute: AppRouter.onUnknownRoute,
      ),
    );
    // Lewati juga timer splash yang terpasang di bawah route utama.
    await tester.pump(const Duration(seconds: 2));
    await tester.pumpAndSettle();

    expect(find.byType(MainShellPage), findsOneWidget);
    expect(find.byType(NavigationBar), findsOneWidget);
  });
}
