import 'package:flutter/material.dart';

import '../../navigation/app_routes.dart';

/// Halaman login pembeli Peukan Rumoh.
///
/// Mendemonstrasikan **push dan pop dengan pengiriman data**:
/// - push ke [AppRoutes.register];
/// - menerima hasil register (nama dan email akun baru) lewat nilai balik
///   `pushNamed`, lalu mengisi otomatis form login.
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _obscure = true;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _openRegister() async {
    // Route dinamis mengembalikan Object?; bentuknya diverifikasi di sini
    // supaya tidak bergantung pada tipe generik MaterialPageRoute.
    final result =
        await Navigator.of(context).pushNamed(AppRoutes.register);

    if (!mounted || result is! Map) return;
    final email = result['email'];
    if (email is String && email.isNotEmpty) {
      _emailController.text = email;
    }
    final name = result['name'];
    if (name is String && name.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Akun "$name" berhasil dibuat. Silakan masuk.'),
        ),
      );
    }
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;

    // Demo tanpa backend: masuk langsung ke shell utama.
    Navigator.of(context).pushNamedAndRemoveUntil(
      AppRoutes.main,
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    // Teal gelap: varian teks dari warna utama agar kontras di atas putih.
    const teal = Color(0xFF0B6E62);

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Icon(Icons.storefront, size: 64, color: teal),
                    const SizedBox(height: 12),
                    Text(
                      'Masuk ke Peukan Rumoh',
                      textAlign: TextAlign.center,
                      style: theme.textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Belanja kebutuhan dapur dari peukan terdekat',
                      textAlign: TextAlign.center,
                      style: theme.textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 28),
                    TextFormField(
                      controller: _emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        labelText: 'Email',
                        prefixIcon: Icon(Icons.email_outlined),
                      ),
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Email wajib diisi';
                        }
                        if (!value.contains('@')) {
                          return 'Format email tidak valid';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _passwordController,
                      obscureText: _obscure,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          tooltip: _obscure
                              ? 'Tampilkan password'
                              : 'Sembunyikan password',
                          icon: Icon(
                            _obscure
                                ? Icons.visibility_outlined
                                : Icons.visibility_off_outlined,
                          ),
                          onPressed: () => setState(() => _obscure = !_obscure),
                        ),
                      ),
                      validator: (value) =>
                          (value == null || value.isEmpty)
                              ? 'Password wajib diisi'
                              : null,
                    ),
                    const SizedBox(height: 24),
                    FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: teal,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: _submit,
                      icon: const Icon(Icons.login),
                      label: const Text('Masuk'),
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: _openRegister,
                      icon: const Icon(Icons.person_add_alt_1),
                      label: const Text('Daftar akun baru'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
