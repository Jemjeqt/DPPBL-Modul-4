import 'package:flutter/material.dart';

import 'demo_data.dart';

/// Keranjang belanja demo yang dipakai bersama oleh halaman detail produk,
/// keranjang, dan shell (badge jumlah item).
///
/// Dibuat sebagai ChangeNotifier sederhana supaya perubahan isi keranjang
/// benar-benar terlihat di semua halaman yang memakainya.
class CartStore extends ChangeNotifier {
  CartStore._();
  static final CartStore instance = CartStore._();

  final List<({DemoProduct product, int qty})> _lines = [];

  List<({DemoProduct product, int qty})> get lines =>
      List.unmodifiable(_lines);

  int get itemCount => _lines.fold(0, (sum, line) => sum + line.qty);

  int get subtotal =>
      _lines.fold(0, (sum, line) => sum + line.product.price * line.qty);

  /// Ongkir tetap sebagai bagian dari simulasi alur DPPB (checkout, bayar).
  int get shippingCost => _lines.isEmpty ? 0 : 12000;

  int get total => subtotal + shippingCost;

  bool contains(int productId) =>
      _lines.any((line) => line.product.id == productId);

  void add(DemoProduct product) {
    for (var i = 0; i < _lines.length; i++) {
      if (_lines[i].product.id == product.id) {
        _lines[i] = (product: product, qty: _lines[i].qty + 1);
        notifyListeners();
        return;
      }
    }
    _lines.add((product: product, qty: 1));
    notifyListeners();
  }

  void changeQty(int productId, int delta) {
    for (var i = 0; i < _lines.length; i++) {
      if (_lines[i].product.id != productId) continue;
      final next = _lines[i].qty + delta;
      if (next <= 0) {
        _lines.removeAt(i);
      } else {
        _lines[i] = (product: _lines[i].product, qty: next);
      }
      notifyListeners();
      return;
    }
  }

  void remove(int productId) {
    _lines.removeWhere((line) => line.product.id == productId);
    notifyListeners();
  }

  void clear() {
    _lines.clear();
    notifyListeners();
  }
}
