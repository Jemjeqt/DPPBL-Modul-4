/// Data demo Peukan Rumoh.
///
/// Sesuai ketentuan tugas, isi halaman sementara dan data ditulis langsung
/// di dalam kode. Nama produk serta harga diambil dari katalog bawaan
/// aplikasi DPPB (LocalCatalogService) supaya demo ini konsisten dengan
/// aplikasi utamanya. Ini data demo, bukan toko sungguhan.
library;

class DemoProduct {
  const DemoProduct({
    required this.id,
    required this.name,
    required this.category,
    required this.price,
    required this.unit,
    required this.emoji,
    required this.seller,
    required this.description,
  });

  final int id;
  final String name;
  final String category;
  final int price;
  final String unit;
  final String emoji;
  final String seller;
  final String description;

  String get priceLabel => 'Rp $price';
}

const List<DemoProduct> demoProducts = [
  DemoProduct(
    id: 1,
    name: 'Bayam Segar',
    category: 'Sayuran',
    price: 8000,
    unit: 'iket',
    emoji: '🥬',
    seller: 'Kios Sayur Banda Aceh',
    description: 'Bayam hijau segar dipetik pagi, cocok untuk tumis dan sayur kuah.',
  ),
  DemoProduct(
    id: 2,
    name: 'Kangkung Hidroponik',
    category: 'Sayuran',
    price: 5000,
    unit: 'ikat',
    emoji: '🌿',
    seller: 'Kios Sayur Banda Aceh',
    description: 'Kangkung renyah tanpa pestisida, panen harian.',
  ),
  DemoProduct(
    id: 3,
    name: 'Mangga Harum Manis (3pcs)',
    category: 'Buah',
    price: 25000,
    unit: 'pack',
    emoji: '🥭',
    seller: 'Toko Buah Lambaro',
    description: 'Mangga matang pohon, manis dan berair.',
  ),
  DemoProduct(
    id: 4,
    name: 'Pisang Tanduk 1 sisir',
    category: 'Buah',
    price: 18000,
    unit: 'sisir',
    emoji: '🍌',
    seller: 'Toko Buah Lambaro',
    description: 'Pisang tanduk untuk pisang goreng dan keulabab.',
  ),
  DemoProduct(
    id: 5,
    name: 'Ayam Potong Segar 1kg',
    category: 'Daging',
    price: 38000,
    unit: 'kg',
    emoji: '🍗',
    seller: 'Rumah Potong Jeulingke',
    description: 'Ayam broiler segar, sudah dibersihkan, siap potong.',
  ),
  DemoProduct(
    id: 6,
    name: 'Ikan Kembung Segar',
    category: 'Ikan',
    price: 32000,
    unit: 'kg',
    emoji: '🐟',
    seller: 'Peukan Ikan Ulee Lheue',
    description: 'Hasil tangkapan pagi, mata masih bening.',
  ),
  DemoProduct(
    id: 7,
    name: 'Bumbu Rendang Instan',
    category: 'Bumbu',
    price: 12000,
    unit: 'bks',
    emoji: '🌶️',
    seller: 'Dapur Bunda Aceh',
    description: 'Bumbu rendang khas Aceh, cukup untuk 1 kg daging.',
  ),
  DemoProduct(
    id: 8,
    name: 'Beras Premium 5kg',
    category: 'Sembako',
    price: 72000,
    unit: 'sak kecil',
    emoji: '🌾',
    seller: 'Kios Sembako Peunayong',
    description: 'Beras pulen putih bersih, wangi dan tahan lama.',
  ),
];

const List<String> demoCategories = [
  'Semua',
  'Sayuran',
  'Buah',
  'Daging',
  'Ikan',
  'Bumbu',
  'Sembako',
];

DemoProduct? findDemoProduct(int? id) {
  for (final product in demoProducts) {
    if (product.id == id) return product;
  }
  return null;
}

class DemoOrderItem {
  const DemoOrderItem({required this.product, required this.qty});

  final DemoProduct product;
  final int qty;

  int get subtotal => product.price * qty;
}

class DemoOrder {
  const DemoOrder({
    required this.id,
    required this.dateLabel,
    required this.status,
    required this.items,
    required this.address,
    required this.paymentMethod,
  });

  static const List<String> statuses = [
    'Diproses',
    'Dikirim',
    'Selesai',
    'Dibatalkan',
  ];

  final int id;
  final String dateLabel;
  final String status;
  final List<DemoOrderItem> items;
  final String address;
  final String paymentMethod;

  int get total =>
      items.fold(0, (sum, item) => sum + item.subtotal) +
      (items.isEmpty ? 0 : 12000);
}

// `final` karena item memakai elemen list demoProducts lewat indeks,
// yang bukan ekspresi konstanta di Dart.
final List<DemoOrder> demoOrders = [
  DemoOrder(
    id: 2401,
    dateLabel: '24 Sep 2026',
    status: 'Diproses',
    address: 'Jl. T. Nyak Arief No. 12, Banda Aceh',
    paymentMethod: 'Transfer Bank',
    items: [
      DemoOrderItem(product: demoProducts[0], qty: 3),
      DemoOrderItem(product: demoProducts[2], qty: 1),
    ],
  ),
  DemoOrder(
    id: 2395,
    dateLabel: '21 Sep 2026',
    status: 'Dikirim',
    address: 'Jl. T. Nyak Arief No. 12, Banda Aceh',
    paymentMethod: 'COD',
    items: [
      DemoOrderItem(product: demoProducts[5], qty: 1),
      DemoOrderItem(product: demoProducts[4], qty: 1),
    ],
  ),
  DemoOrder(
    id: 2310,
    dateLabel: '12 Sep 2026',
    status: 'Selesai',
    address: 'Jl. Pocut Baren No. 3, Banda Aceh',
    paymentMethod: 'Transfer Bank',
    items: [DemoOrderItem(product: demoProducts[7], qty: 2)],
  ),
];
