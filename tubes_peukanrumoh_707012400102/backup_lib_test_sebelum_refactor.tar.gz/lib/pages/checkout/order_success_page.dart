import 'package:flutter/material.dart';

import '../../navigation/app_routes.dart';

/// Halaman konfirmasi pesanan berhasil.
///
/// Menerima [OrderSuccessArgs] dari route checkout, lalu menyediakan
/// dua navigasi: kembali ke beranda, atau lihat riwayat pesanan.
class OrderSuccessPage extends StatelessWidget {
  const OrderSuccessPage({super.key, required this.args});

  final OrderSuccessArgs args;

  @override
  Widget build(BuildContext context) {
    const teal = Color(0xFF0B6E62);

    return Scaffold(
      appBar: AppBar(title: const Text('Pesanan Dibuat')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  color: Color(0x1A0B6E62),
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.check_circle_outline,
                  size: 64,
                  color: teal,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Terima kasih!',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              Text(
                'Pesanan #${args.orderId} sebesar Rp ${args.total} sedang '
                'diproses. Detail pesanan bisa dilihat di Riwayat Pesanan.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: teal,
                  foregroundColor: Colors.white,
                ),
                onPressed: () {
                  Navigator.of(context)
                      .pushNamedAndRemoveUntil(AppRoutes.main, (r) => false);
                },
                icon: const Icon(Icons.storefront),
                label: const Text('Kembali ke Beranda'),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () {
                  Navigator.of(context)
                      .pushNamedAndRemoveUntil(AppRoutes.main, (r) => false);
                  Navigator.of(context).pushNamed(AppRoutes.orders);
                },
                icon: const Icon(Icons.receipt_long_outlined),
                label: const Text('Lihat Riwayat Pesanan'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
