import 'package:flutter/material.dart';

import '../../navigation/app_routes.dart';

/// Checkout demo: menerima [CheckoutArgs] dari keranjang, menampilkan
/// ringkasan pesanan, lalu pop dengan data `true` + push halaman sukses.
class CheckoutPage extends StatefulWidget {
  const CheckoutPage({super.key, required this.args});

  final CheckoutArgs args;

  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  String _payment = 'Transfer Bank';
  final _addressController = TextEditingController(
    text: 'Jl. T. Nyak Arief No. 12, Banda Aceh',
  );

  @override
  void dispose() {
    _addressController.dispose();
    super.dispose();
  }

  void _placeOrder() {
    final orderId = DateTime.now().millisecondsSinceEpoch % 100000;
    final total = widget.args.total;

    // Pop dengan data: keranjang membaca `true` lalu mengosongkan diri.
    Navigator.of(context).pop(true);

    Navigator.of(context).pushNamed(
      AppRoutes.orderSuccess,
      arguments: OrderSuccessArgs(orderId: orderId, total: total),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final args = widget.args;

    return Scaffold(
      appBar: AppBar(title: const Text('Checkout')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Pesanan untuk ${args.buyerName}',
              style: theme.textTheme.titleMedium),
          const SizedBox(height: 12),
          if (args.lines.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text('Tidak ada item untuk di-checkout.'),
              ),
            )
          else
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    for (final line in args.lines)
                      ListTile(
                        dense: true,
                        leading: Text(line.emoji,
                            style: const TextStyle(fontSize: 22)),
                        title: Text(line.name,
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        trailing: Text('Rp ${line.subtotal}'),
                        subtitle: Text('${line.price} x ${line.qty}'),
                      ),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 16),
          TextField(
            controller: _addressController,
            maxLines: 2,
            decoration: const InputDecoration(
              labelText: 'Alamat pengiriman',
              prefixIcon: Icon(Icons.local_shipping_outlined),
            ),
          ),
          const SizedBox(height: 16),
          Text('Metode pembayaran', style: theme.textTheme.titleSmall),
          RadioGroup<String>(
            groupValue: _payment,
            onChanged: (value) => setState(() => _payment = value!),
            child: const Column(
              children: [
                RadioListTile<String>(
                  value: 'Transfer Bank',
                  title: Text('Transfer Bank'),
                ),
                RadioListTile<String>(
                  value: 'COD',
                  title: Text('Bayar di tempat (COD)'),
                ),
              ],
            ),
          ),
          const Divider(height: 24),
          _Row(label: 'Total', value: 'Rp ${args.total}', emphasize: true),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: args.lines.isEmpty ? null : _placeOrder,
            icon: const Icon(Icons.check_circle_outline),
            label: const Text('Buat Pesanan'),
          ),
        ],
      ),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row({
    required this.label,
    required this.value,
    this.emphasize = false,
  });

  final String label;
  final String value;
  final bool emphasize;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: emphasize
              ? theme.textTheme.titleMedium
              : theme.textTheme.bodyMedium,
        ),
        Text(
          value,
          style: emphasize
              ? theme.textTheme.titleMedium
              : theme.textTheme.bodyMedium,
        ),
      ],
    );
  }
}
