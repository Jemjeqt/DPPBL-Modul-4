import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';
import 'home/home_page.dart';
import 'orders/orders_page.dart';
import 'profile/profile_page.dart';
import 'widgets/app_drawer.dart';

/// Shell utama aplikasi: satu Scaffold dengan navigasi adaptif.
///
/// - Layar lebar (>= 900px): [NavigationRail] yang bisa diperluas.
/// - Layar sempit: [NavigationBar] di bawah.
/// - Keduanya ditambah [AppDrawer] (NavigationDrawer) dari AppBar.
///
/// Materi yang dicakup: NavigationBar, NavigationRail adaptif,
/// NavigationDrawer, dan tab navigation (IndexedStack).
class MainShellPage extends StatefulWidget {
  const MainShellPage({super.key});

  @override
  State<MainShellPage> createState() => _MainShellPageState();
}

class _ShellTab {
  const _ShellTab({
    required this.label,
    required this.icon,
    required this.selectedIcon,
  });

  final String label;
  final IconData icon;
  final IconData selectedIcon;
}

class _MainShellPageState extends State<MainShellPage> {
  int _currentIndex = 0;
  bool _railExtended = false;

  static const List<_ShellTab> _tabs = [
    _ShellTab(
      label: 'Beranda',
      icon: Icons.storefront_outlined,
      selectedIcon: Icons.storefront,
    ),
    _ShellTab(
      label: 'Pesanan',
      icon: Icons.receipt_long_outlined,
      selectedIcon: Icons.receipt_long,
    ),
    _ShellTab(
      label: 'Profil',
      icon: Icons.person_outline,
      selectedIcon: Icons.person,
    ),
  ];

  void _selectTab(int index) => setState(() => _currentIndex = index);

  void _openCart() {
    Navigator.of(context).pushNamed(AppRoutes.cart);
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width >= 900;

    // IndexedStack menjaga state tiap tab tetap hidup saat bergantian.
    const pages = [
      HomePage(),
      OrdersPage(),
      ProfilePage(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(_tabs[_currentIndex].label),
        leading: Builder(
          builder: (drawerContext) => IconButton(
            tooltip: 'Buka menu',
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(drawerContext).openDrawer(),
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Keranjang',
            icon: const Icon(Icons.shopping_cart_outlined),
            onPressed: _openCart,
          ),
        ],
      ),
      drawer: const AppDrawer(),
      body: SafeArea(
        child: Row(
          children: [
            if (wide)
              NavigationRail(
                selectedIndex: _currentIndex,
                onDestinationSelected: _selectTab,
                extended: _railExtended,
                minExtendedWidth: 180,
                labelType: _railExtended
                    ? NavigationRailLabelType.none
                    : NavigationRailLabelType.all,
                leading: FloatingActionButton(
                  heroTag: 'rail_cart',
                  tooltip: 'Keranjang',
                  onPressed: _openCart,
                  child: const Icon(Icons.shopping_cart_outlined),
                ),
                trailing: IconButton(
                  tooltip: _railExtended ? 'Ciutkan menu' : 'Perluas menu',
                  icon: Icon(
                    _railExtended ? Icons.menu_open : Icons.menu,
                  ),
                  onPressed: () =>
                      setState(() => _railExtended = !_railExtended),
                ),
                destinations: [
                  for (final tab in _tabs)
                    NavigationRailDestination(
                      icon: Icon(tab.icon),
                      selectedIcon: Icon(tab.selectedIcon),
                      label: Text(tab.label),
                    ),
                ],
              ),
            Expanded(
              child: IndexedStack(index: _currentIndex, children: pages),
            ),
          ],
        ),
      ),
      bottomNavigationBar: wide
          ? null
          : NavigationBar(
              selectedIndex: _currentIndex,
              onDestinationSelected: _selectTab,
              destinations: [
                for (final tab in _tabs)
                  NavigationDestination(
                    icon: Icon(tab.icon),
                    selectedIcon: Icon(tab.selectedIcon),
                    label: tab.label,
                  ),
              ],
            ),
    );
  }
}
