import 'package:flutter/material.dart';

/// Tentang aplikasi: ringkasan materi navigasi yang dipakai di demo ini.
class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    const teal = Color(0xFF11998E);

    return Scaffold(
      appBar: AppBar(title: const Text('Tentang Aplikasi')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Icon(Icons.storefront, size: 64, color: teal),
          const SizedBox(height: 12),
          Text(
            'Peukan Rumoh',
            textAlign: TextAlign.center,
            style: theme.textTheme.headlineSmall,
          ),
          Text(
            'Demo navigasi tugas DPPB',
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium,
          ),
          const SizedBox(height: 24),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Materi navigasi yang diterapkan:',
                      style: theme.textTheme.titleSmall),
                  const SizedBox(height: 8),
                  const Text('1. Named routes (app_routes.dart + app_router.dart)'),
                  const Text('2. Push dan pop dengan pengiriman data'),
                  const Text('3. NavigationBar (layar sempit)'),
                  const Text('4. NavigationRail adaptif (layar lebar)'),
                  const Text('5. NavigationDrawer'),
                  const Text('6. Tab navigation (Riwayat Pesanan)'),
                  const SizedBox(height: 8),
                  Text(
                    'onUnknownRoute menangkap nama route salah tulis agar '
                    'aplikasi tidak berhenti paksa.',
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Catatan', style: theme.textTheme.titleSmall),
                  const SizedBox(height: 8),
                  const Text(
                    'Produk, pesanan, dan profil di halaman ini adalah data '
                    'demo yang ditulis langsung di kode (boleh sementara '
                    'sesuai ketentuan), bukan toko sungguhan.',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
