import 'dart:async';

import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';

/// Halaman splash ala Peukan Rumoh: gradasi teal, logo toko, lalu pindah
/// ke halaman login memakai named route (pushReplacementNamed).
class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scale;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _scale = CurvedAnimation(parent: _controller, curve: Curves.easeOutBack);

    _timer = Timer(const Duration(milliseconds: 1600), _goToLogin);
  }

  @override
  void dispose() {
    // Timer dibatalkan agar tidak menggantung saat splash sudah tak dipakai
    // (misal route utama dimuat langsung lewat named route).
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _goToLogin() {
    if (!mounted) return;
    // Hanya pindah kalau splash masih route teratas. Kalau halaman lain
    // sudah dibuka di atasnya (misal /main dimuat langsung), splash tidak
    // boleh menggantikan route teratas yang sedang aktif.
    final splashIsCurrent = ModalRoute.of(context)?.isCurrent ?? false;
    if (!splashIsCurrent) return;
    Navigator.of(context).pushReplacementNamed(AppRoutes.login);
  }

  @override
  Widget build(BuildContext context) {
    // Gradasi teal identitas Peukan Rumoh (dari DPPB), dibuat lebih gelap
    // agar teks putih di atasnya tetap lolos kontras WCAG AA (R-25).
    const tealStart = Color(0xFF0B6E62);
    const tealEnd = Color(0xFF0D8472);
    const accent = Color(0xFFFFD54F);

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [tealStart, tealEnd],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ScaleTransition(
                scale: _scale,
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.2),
                        blurRadius: 24,
                        offset: const Offset(0, 10),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.storefront,
                    size: 60,
                    color: tealStart,
                  ),
                ),
              ),
              const SizedBox(height: 24),
              RichText(
                text: const TextSpan(
                  children: [
                    TextSpan(
                      text: 'Peukan ',
                      style: TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    TextSpan(
                      text: 'Rumoh',
                      style: TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.bold,
                        color: accent,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Pasar Online Terpercaya',
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.white,
                  letterSpacing: 1.2,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
