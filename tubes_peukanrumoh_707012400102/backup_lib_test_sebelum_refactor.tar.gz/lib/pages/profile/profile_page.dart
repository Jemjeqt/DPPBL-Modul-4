import 'package:flutter/material.dart';

import '../../navigation/app_routes.dart';
import '../../theme/theme_controller.dart';
import '../data/cart_store.dart';

/// Profil pembeli demo.
///
/// Aksi "Buka drawer" memperlihatkan NavigationDrawer dari mana pun,
/// dan item menu mengarah ke route terdaftar (tidak ada tautan mati).
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cartCount = CartStore.instance.itemCount;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 32,
                  backgroundColor: Color(0xFF0B6E62),
                  foregroundColor: Colors.white,
                  child: Text(
                    'PD',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Pembeli Demo',
                          style: theme.textTheme.titleMedium),
                      const SizedBox(height: 4),
                      Text(
                        'pembeli.demo@contoh.id',
                        style: theme.textTheme.bodySmall,
                      ),
                      Text(
                        'Jl. T. Nyak Arief No. 12, Banda Aceh',
                        style: theme.textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.shopping_cart_outlined),
                title: const Text('Keranjang'),
                subtitle: Text('$cartCount item di keranjang'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () =>
                    Navigator.of(context).pushNamed(AppRoutes.cart),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.receipt_long_outlined),
                title: const Text('Riwayat Pesanan'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () =>
                    Navigator.of(context).pushNamed(AppRoutes.orders),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.info_outline),
                title: const Text('Tentang Aplikasi'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () =>
                    Navigator.of(context).pushNamed(AppRoutes.about),
              ),
              const Divider(height: 1),
              ListenableBuilder(
                listenable: ThemeController.instance,
                builder: (context, _) => SwitchListTile(
                  secondary: const Icon(Icons.dark_mode_outlined),
                  title: const Text('Mode gelap'),
                  value: ThemeController.instance.isDark,
                  onChanged: ThemeController.instance.setDark,
                ),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Keluar (ke halaman Login)'),
                onTap: () {
                  Navigator.of(context)
                      .pushNamedAndRemoveUntil(AppRoutes.login, (r) => false);
                },
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        Text(
          'Data demo ditulis langsung di kode sesuai ketentuan tugas.',
          textAlign: TextAlign.center,
          style: theme.textTheme.bodySmall,
        ),
      ],
    );
  }
}
