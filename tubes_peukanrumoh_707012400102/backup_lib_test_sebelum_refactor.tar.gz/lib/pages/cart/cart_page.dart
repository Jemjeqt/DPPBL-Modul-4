import 'package:flutter/material.dart';

import '../../navigation/app_routes.dart';
import '../data/cart_store.dart';

/// Keranjang belanja demo.
///
/// Tombol "Lanjut ke Checkout" push named route [AppRoutes.checkout]
/// sambil mengirim [CheckoutArgs] berisi isi keranjang (push dengan data),
/// lalu membaca nilai balik `bool` saat halaman checkout pop.
class CartPage extends StatefulWidget {
  const CartPage({super.key});

  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  @override
  void initState() {
    super.initState();
    CartStore.instance.addListener(_onCartChanged);
  }

  @override
  void dispose() {
    CartStore.instance.removeListener(_onCartChanged);
    super.dispose();
  }

  void _onCartChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _goToCheckout() async {
    final lines = CartStore.instance.lines;
    final args = CheckoutArgs(
      buyerName: 'Pembeli Demo',
      lines: [
        for (final line in lines)
          OrderLineArgs(
            productId: line.product.id,
            name: line.product.name,
            emoji: line.product.emoji,
            price: line.product.price,
            qty: line.qty,
          ),
      ],
    );

    final ordered =
        await Navigator.of(context).pushNamed(AppRoutes.checkout,
            arguments: args);

    // Checkout pop dengan data: `true` berarti pesanan dibuat.
    if (ordered is bool && ordered && mounted) {
      CartStore.instance.clear();
      Navigator.of(context)
          .pushNamedAndRemoveUntil(AppRoutes.main, (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final store = CartStore.instance;
    final lines = store.lines;

    return Scaffold(
      appBar: AppBar(title: const Text('Keranjang')),
      body: lines.isEmpty
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.shopping_cart_outlined, size: 64),
                  const SizedBox(height: 12),
                  Text(
                    'Keranjang masih kosong',
                    style: theme.textTheme.titleMedium,
                  ),
                  const SizedBox(height: 4),
                  const Text('Tambahkan produk dari halaman Beranda.'),
                ],
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                for (final line in lines)
                  Card(
                    margin: const EdgeInsets.only(bottom: 8),
                    child: ListTile(
                      leading: Text(
                        line.product.emoji,
                        style: const TextStyle(fontSize: 28),
                      ),
                      title: Text(
                        line.product.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      subtitle: Text(
                        '${line.product.priceLabel} x ${line.qty}',
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            tooltip: 'Kurangi',
                            onPressed: () => store.changeQty(line.product.id, -1),
                            icon: const Icon(Icons.remove_circle_outline),
                          ),
                          Text('${line.qty}'),
                          IconButton(
                            tooltip: 'Tambah',
                            onPressed: () => store.changeQty(line.product.id, 1),
                            icon: const Icon(Icons.add_circle_outline),
                          ),
                          IconButton(
                            tooltip: 'Hapus item',
                            onPressed: () => store.remove(line.product.id),
                            icon: const Icon(Icons.delete_outline),
                          ),
                        ],
                      ),
                    ),
                  ),
                const SizedBox(height: 8),
                _SummaryRow(
                  label: 'Subtotal',
                  value: 'Rp ${store.subtotal}',
                ),
                _SummaryRow(
                  label: 'Ongkos kirim',
                  value: 'Rp ${store.shippingCost}',
                ),
                const Divider(height: 24),
                _SummaryRow(
                  label: 'Total',
                  value: 'Rp ${store.total}',
                  emphasize: true,
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: _goToCheckout,
                  icon: const Icon(Icons.payments_outlined),
                  label: Text('Lanjut ke Checkout (Rp ${store.total})'),
                ),
              ],
            ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({
    required this.label,
    required this.value,
    this.emphasize = false,
  });

  final String label;
  final String value;
  final bool emphasize;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: emphasize
                ? theme.textTheme.titleMedium
                : theme.textTheme.bodyMedium,
          ),
          Text(
            value,
            style: emphasize
                ? theme.textTheme.titleMedium
                : theme.textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}
