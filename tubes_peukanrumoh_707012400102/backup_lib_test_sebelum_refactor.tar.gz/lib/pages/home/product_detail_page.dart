import 'package:flutter/material.dart';

import '../../navigation/app_routes.dart';
import '../data/cart_store.dart';
import '../data/demo_data.dart';

/// Detail produk demo.
///
/// Argumen [ProductPageArgs] diterima dari route (push dengan data),
/// lalu tombol keranjang menambahkan item ke [CartStore] dan memakai
/// SnackBar dengan aksi "Lihat Keranjang" (pushNamed ke /cart).
class ProductDetailPage extends StatelessWidget {
  const ProductDetailPage({super.key, required this.args});

  final ProductPageArgs args;

  @override
  Widget build(BuildContext context) {
    final product = findDemoProduct(args.productId);
    final theme = Theme.of(context);
    const teal = Color(0xFF0B6E62);

    if (product == null) {
      // ID tak dikenal (misal data demo berubah): tampilkan keadaan kosong.
      return Scaffold(
        appBar: AppBar(title: const Text('Produk')),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.inventory_2_outlined, size: 56),
              const SizedBox(height: 12),
              const Text('Produk tidak ditemukan.'),
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Kembali'),
              ),
            ],
          ),
        ),
      );
    }

    final alreadyInCart = CartStore.instance.contains(product.id);

    return Scaffold(
      appBar: AppBar(title: Text(product.category)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            height: 180,
            decoration: BoxDecoration(
              color: const Color(0xFF0B6E62).withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(16),
            ),
            alignment: Alignment.center,
            child: Text(product.emoji, style: const TextStyle(fontSize: 80)),
          ),
          const SizedBox(height: 16),
          Text(product.name, style: theme.textTheme.headlineSmall),
          const SizedBox(height: 4),
          Text(
            '${product.priceLabel} / ${product.unit}',
            style: theme.textTheme.titleMedium?.copyWith(
              color: teal,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Dijual oleh ${product.seller}',
            style: theme.textTheme.bodySmall,
          ),
          const SizedBox(height: 16),
          Text(product.description, style: theme.textTheme.bodyMedium),
          const SizedBox(height: 24),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: teal,
              foregroundColor: Colors.white,
            ),
            onPressed: () {
              CartStore.instance.add(product);
              ScaffoldMessenger.of(context)
                ..hideCurrentSnackBar()
                ..showSnackBar(
                  SnackBar(
                    content: Text('${product.name} masuk keranjang.'),
                    action: SnackBarAction(
                      label: 'Lihat Keranjang',
                      onPressed: () {
                        Navigator.of(context).pushNamed(AppRoutes.cart);
                      },
                    ),
                  ),
                );
            },
            icon: Icon(
              alreadyInCart ? Icons.add_shopping_cart : Icons.add,
            ),
            label: Text(
              alreadyInCart
                  ? 'Tambah lagi ke Keranjang'
                  : 'Tambahkan ke Keranjang',
            ),
          ),
        ],
      ),
    );
  }
}
