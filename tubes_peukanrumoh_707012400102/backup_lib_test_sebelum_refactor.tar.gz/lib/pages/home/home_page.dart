import 'package:flutter/material.dart';

import '../../navigation/app_routes.dart';
import '../data/demo_data.dart';

/// Beranda: katalog demo Peukan Rumoh dengan filter kategori dan pencarian.
///
/// Menekan kartu produk akan push named route [AppRoutes.productDetail]
/// dengan [ProductPageArgs] (push dengan pengiriman data).
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _category = 'Semua';
  String _query = '';

  List<DemoProduct> get _filtered {
    return demoProducts.where((product) {
      if (_category != 'Semua' && product.category != _category) return false;
      if (_query.isNotEmpty &&
          !product.name.toLowerCase().contains(_query.toLowerCase())) {
        return false;
      }
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final products = _filtered;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        Text(
          'Mau belanja apa hari ini?',
          style: theme.textTheme.headlineSmall,
        ),
        const SizedBox(height: 4),
        Text(
          'Hasil segar dari peukan sekitar Banda Aceh.',
          style: theme.textTheme.bodyMedium,
        ),
        const SizedBox(height: 16),
        TextField(
          onChanged: (value) => setState(() => _query = value),
          decoration: const InputDecoration(
            hintText: 'Cari produk, misal "bayam"',
            prefixIcon: Icon(Icons.search),
          ),
        ),
        const SizedBox(height: 12),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              for (final category in demoCategories)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(category),
                    selected: _category == category,
                    onSelected: (_) => setState(() => _category = category),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 16),
        if (products.isEmpty)
          // R-27: keadaan kosong tetap dirancang, bukan layar putih.
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 48),
            child: Column(
              children: [
                const Icon(Icons.search_off, size: 56),
                const SizedBox(height: 12),
                Text(
                  'Tidak ada produk yang cocok',
                  style: theme.textTheme.titleMedium,
                ),
                const SizedBox(height: 4),
                Text(
                  'Coba kata kunci lain atau pilih kategori "Semua".',
                  style: theme.textTheme.bodySmall,
                ),
              ],
            ),
          )
        else
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 220,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.78,
            ),
            itemCount: products.length,
            itemBuilder: (context, index) => _ProductCard(
              product: products[index],
              onTap: () {
                Navigator.of(context).pushNamed(
                  AppRoutes.productDetail,
                  arguments:
                      ProductPageArgs(productId: products[index].id),
                );
              },
            ),
          ),
      ],
    );
  }
}

class _ProductCard extends StatelessWidget {
  const _ProductCard({required this.product, required this.onTap});

  final DemoProduct product;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    const teal = Color(0xFF0B6E62);

    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Center(
                  child: Text(product.emoji, style: const TextStyle(fontSize: 40)),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                product.name,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.titleSmall,
              ),
              const SizedBox(height: 2),
              Text(
                '${product.priceLabel} / ${product.unit}',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: teal,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
