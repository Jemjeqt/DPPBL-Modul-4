import 'package:flutter/material.dart';

import '../navigation/app_routes.dart';

/// Halaman fallback untuk route yang tidak dikenal (onUnknownRoute).
///
/// Dipanggil saat nama route salah tulis, misal `/prodak` alih-alih
/// `/product`. Aplikasi tetap hidup dan pengguna bisa kembali.
class NotFoundPage extends StatelessWidget {
  const NotFoundPage({super.key, this.unknownRouteName});

  final String? unknownRouteName;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Halaman tidak ditemukan')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.location_off_outlined, size: 72),
              const SizedBox(height: 16),
              Text(
                '404',
                style: Theme.of(context).textTheme.displaySmall,
              ),
              const SizedBox(height: 8),
              Text(
                unknownRouteName == null || unknownRouteName!.isEmpty
                    ? 'Halaman yang kamu cari tidak ada.'
                    : 'Route "$unknownRouteName" tidak terdaftar.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: () {
                  Navigator.of(context)
                      .pushNamedAndRemoveUntil(AppRoutes.main, (r) => false);
                },
                icon: const Icon(Icons.home_outlined),
                label: const Text('Kembali ke Beranda'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
