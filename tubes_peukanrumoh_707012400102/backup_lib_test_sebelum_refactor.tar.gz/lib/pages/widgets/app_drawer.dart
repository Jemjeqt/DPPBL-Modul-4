import 'package:flutter/material.dart';

import '../../navigation/app_routes.dart';

/// NavigationDrawer Peukan Rumoh.
///
/// Semua item mengarah ke route yang benar-benar terdaftar di
/// [AppRouter] (R-24: tidak ada tautan mati). Tutup drawer lebih dulu
/// supaya halaman tujuan muncul di atas shell, bukan di dalam drawer.
class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    const teal = Color(0xFF0B6E62);

    return NavigationDrawer(
      selectedIndex: null,
      onDestinationSelected: (index) {
        Navigator.of(context).pop(); // tutup drawer
        final (route, args) = switch (index) {
          0 => (AppRoutes.main, null),
          1 => (AppRoutes.cart, null),
          2 => (AppRoutes.orders, null),
          3 => (AppRoutes.profile, null),
          4 => (AppRoutes.about, null),
          _ => (AppRoutes.main, null),
        };
        if (route == AppRoutes.main) {
          Navigator.of(context)
              .pushNamedAndRemoveUntil(AppRoutes.main, (r) => false);
          return;
        }
        Navigator.of(context).pushNamed(route, arguments: args);
      },
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 24, 24, 8),
          child: Row(
            children: [
              const CircleAvatar(
                backgroundColor: teal,
                foregroundColor: Colors.white,
                child: Icon(Icons.storefront),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Peukan Rumoh',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  Text(
                    'Pembeli Demo',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ],
          ),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.storefront_outlined),
          selectedIcon: Icon(Icons.storefront),
          label: Text('Beranda'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.shopping_cart_outlined),
          selectedIcon: Icon(Icons.shopping_cart),
          label: Text('Keranjang'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.receipt_long_outlined),
          selectedIcon: Icon(Icons.receipt_long),
          label: Text('Riwayat Pesanan'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.person_outline),
          selectedIcon: Icon(Icons.person),
          label: Text('Profil'),
        ),
        const NavigationDrawerDestination(
          icon: Icon(Icons.info_outline),
          selectedIcon: Icon(Icons.info),
          label: Text('Tentang Aplikasi'),
        ),
      ],
    );
  }
}
