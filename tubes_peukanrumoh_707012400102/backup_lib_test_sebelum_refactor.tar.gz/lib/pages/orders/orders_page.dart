import 'package:flutter/material.dart';

import '../../navigation/app_routes.dart';
import '../data/demo_data.dart';

/// Riwayat pesanan dengan **tab navigation**: TabBar + TabBarView di
/// dalam satu halaman (Diproses, Dikirim, Selesai, Semua).
///
/// Menekan kartu pesanan push [AppRoutes.orderDetail] dengan data
/// [DemoOrder].
class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key});

  @override
  Widget build(BuildContext context) {
    final statuses = ['Semua', ...DemoOrder.statuses];

    return DefaultTabController(
      length: statuses.length,
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: const Text('Pesanan'),
          bottom: TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            tabs: [
              for (final status in statuses) Tab(text: status),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            for (final status in statuses)
              _OrderList(statusFilter: status),
          ],
        ),
      ),
    );
  }
}

class _OrderList extends StatelessWidget {
  const _OrderList({required this.statusFilter});

  final String statusFilter;

  @override
  Widget build(BuildContext context) {
    final orders = statusFilter == 'Semua'
        ? demoOrders
        : demoOrders.where((order) => order.status == statusFilter).toList();

    if (orders.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.receipt_long_outlined, size: 56),
            const SizedBox(height: 12),
            Text(
              'Belum ada pesanan "$statusFilter"',
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ],
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        for (final order in orders)
          Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              onTap: () {
                Navigator.of(context).pushNamed(
                  AppRoutes.orderDetail,
                  arguments: order,
                );
              },
              leading: const Icon(Icons.receipt_long_outlined),
              title: Text('Pesanan #${order.id}'),
              subtitle: Text('${order.dateLabel} . ${order.items.length} item'),
              trailing: Chip(
                label: Text(
                  order.status,
                  style: const TextStyle(fontSize: 12),
                ),
                visualDensity: VisualDensity.compact,
              ),
            ),
          ),
      ],
    );
  }
}
