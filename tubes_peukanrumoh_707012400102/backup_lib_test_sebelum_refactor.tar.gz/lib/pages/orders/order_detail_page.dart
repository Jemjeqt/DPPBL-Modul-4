import 'package:flutter/material.dart';

import '../data/demo_data.dart';

/// Detail pesanan demo; menerima [DemoOrder] dari route (push dengan data).
class OrderDetailPage extends StatelessWidget {
  const OrderDetailPage({super.key, required this.order});

  final DemoOrder order;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: Text('Pesanan #${order.id}')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Chip(label: Text(order.status)),
              const SizedBox(width: 8),
              Text(order.dateLabel, style: theme.textTheme.bodySmall),
            ],
          ),
          const SizedBox(height: 16),
          Text('Item', style: theme.textTheme.titleSmall),
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                children: [
                  for (final item in order.items)
                    ListTile(
                      dense: true,
                      leading: Text(item.product.emoji,
                          style: const TextStyle(fontSize: 22)),
                      title: Text(item.product.name),
                      subtitle: Text(
                        '${item.product.priceLabel} x ${item.qty}',
                      ),
                      trailing: Text('Rp ${item.subtotal}'),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text('Pengiriman', style: theme.textTheme.titleSmall),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              leading: const Icon(Icons.local_shipping_outlined),
              title: const Text('Dikirim ke alamat pembeli'),
              subtitle: Text(order.address),
              trailing: Text(order.paymentMethod),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('Total', style: theme.textTheme.titleMedium),
              Text('Rp ${order.total}', style: theme.textTheme.titleMedium),
            ],
          ),
        ],
      ),
    );
  }
}
