/// Nama route aplikasi Peukan Rumoh.
///
/// Semua perpindahan halaman melewati file ini: halaman lain hanya
/// memanggil `Navigator.pushNamed(AppRoutes.x)`, tidak pernah membangun
/// widget halaman tujuan secara langsung.
class AppRoutes {
  AppRoutes._();

  /// Halaman splash (initial route).
  static const String splash = '/';

  /// Halaman login pembeli.
  static const String login = '/login';

  /// Halaman register pembeli.
  static const String register = '/register';

  /// Shell utama: NavigationBar / NavigationRail adaptif + NavigationDrawer.
  static const String main = '/main';

  /// Detail produk; wajib mengirim [ProductPageArgs].
  static const String productDetail = '/product';

  /// Keranjang belanja.
  static const String cart = '/cart';

  /// Checkout; mengirim [CheckoutArgs], mengembalikan `bool` saat pop.
  static const String checkout = '/checkout';

  /// Konfirmasi pesanan berhasil; mengirim [OrderSuccessArgs].
  static const String orderSuccess = '/order-success';

  /// Riwayat pesanan (juga diakses dari drawer).
  static const String orders = '/orders';

  /// Profil pembeli (juga diakses dari drawer).
  static const String profile = '/profile';

  /// Tentang aplikasi.
  static const String about = '/about';

  /// Detail pesanan dari riwayat; mengirim [DemoOrder].
  static const String orderDetail = '/order-detail';

  /// Halaman "route tidak dikenal" (fallback onUnknownRoute).
  static const String notFound = '/not-found';
}

/// Argumen wajib untuk route [AppRoutes.productDetail].
class ProductPageArgs {
  const ProductPageArgs({required this.productId});

  final int productId;
}

/// Satu baris pesanan yang dikirim dari keranjang ke checkout.
class OrderLineArgs {
  const OrderLineArgs({
    required this.productId,
    required this.name,
    required this.emoji,
    required this.price,
    required this.qty,
  });

  final int productId;
  final String name;
  final String emoji;
  final int price;
  final int qty;

  int get subtotal => price * qty;
}

/// Argumen untuk route [AppRoutes.checkout].
class CheckoutArgs {
  const CheckoutArgs({this.buyerName = 'Pembeli Demo', required this.lines});

  final String buyerName;
  final List<OrderLineArgs> lines;

  int get total =>
      lines.fold(0, (sum, line) => sum + line.subtotal) +
      (lines.isEmpty ? 0 : 12000);
}

/// Argumen untuk route [AppRoutes.orderSuccess].
class OrderSuccessArgs {
  const OrderSuccessArgs({required this.orderId, required this.total});

  final int orderId;
  final int total;
}
