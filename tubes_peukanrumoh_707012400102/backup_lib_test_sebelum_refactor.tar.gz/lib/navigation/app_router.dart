import 'package:flutter/material.dart';

import '../pages/about_page.dart';
import '../pages/auth/login_page.dart';
import '../pages/auth/register_page.dart';
import '../pages/cart/cart_page.dart';
import '../pages/checkout/checkout_page.dart';
import '../pages/checkout/order_success_page.dart';
import '../pages/data/demo_data.dart';
import '../pages/home/product_detail_page.dart';
import '../pages/main_shell_page.dart';
import '../pages/not_found_page.dart';
import '../pages/orders/order_detail_page.dart';
import '../pages/orders/orders_page.dart';
import '../pages/profile/profile_page.dart';
import '../pages/splash_page.dart';
import 'app_routes.dart';

/// Router terpusat aplikasi Peukan Rumoh.
///
/// Semua perpindahan halaman memakai nama route dari [AppRoutes] dan
/// dipetakan DI SINI saja. Halaman tidak pernah di-push langsung lewat
/// konstruktor oleh halaman lain, sehingga:
/// - menambah atau mengubah halaman cukup di file ini;
/// - salah tulis nama route jatuh ke [onUnknownRoute], bukan crash.
class AppRouter {
  AppRouter._();

  /// Dipasang ke `MaterialApp.onGenerateRoute`.
  ///
  /// Mengembalikan `null` untuk nama yang tidak dikenal sehingga Flutter
  /// meneruskan penanganannya ke `onUnknownRoute`.
  static Route<dynamic>? onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case AppRoutes.splash:
        return _page(settings, const SplashPage());

      case AppRoutes.login:
        return _page(settings, const LoginPage());

      case AppRoutes.register:
        return _page(settings, const RegisterPage());

      case AppRoutes.main:
        return _page(settings, const MainShellPage());

      case AppRoutes.productDetail:
        final args = settings.arguments;
        if (args is ProductPageArgs) {
          return _page(settings, ProductDetailPage(args: args));
        }
        // Route detail tanpa argumen yang sah dianggap tidak dikenal.
        return null;

      case AppRoutes.cart:
        return _page(settings, const CartPage());

      case AppRoutes.checkout:
        final args = settings.arguments;
        return _page(
          settings,
          CheckoutPage(
            args: args is CheckoutArgs
                ? args
                : const CheckoutArgs(buyerName: 'Pembeli Demo', lines: []),
          ),
        );

      case AppRoutes.orderSuccess:
        final args = settings.arguments;
        if (args is OrderSuccessArgs) {
          return _page(settings, OrderSuccessPage(args: args));
        }
        return null;

      case AppRoutes.orders:
        return _page(settings, const OrdersPage());

      case AppRoutes.profile:
        return _page(settings, const ProfilePage());

      case AppRoutes.about:
        return _page(settings, const AboutPage());

      case AppRoutes.orderDetail:
        final args = settings.arguments;
        if (args is DemoOrder) {
          return _page(settings, OrderDetailPage(order: args));
        }
        return null;

      case AppRoutes.notFound:
        return _page(settings, const NotFoundPage());

      default:
        return null;
    }
  }

  /// Fallback `MaterialApp.onUnknownRoute`: dipanggil ketika `pushNamed`
  /// menerima nama route yang tidak terdaftar, misal salah ketik
  /// `/prodak` alih-alih `/product`. Aplikasi tetap hidup dan menampilkan
  /// halaman [NotFoundPage] alih-alih berhenti paksa.
  static Route<dynamic> onUnknownRoute(RouteSettings settings) {
    return MaterialPageRoute<dynamic>(
      settings: settings,
      builder: (_) => NotFoundPage(unknownRouteName: settings.name),
    );
  }

  static MaterialPageRoute<T> _page<T>(RouteSettings settings, Widget page) {
    return MaterialPageRoute<T>(
      settings: settings,
      builder: (_) => page,
    );
  }
}
