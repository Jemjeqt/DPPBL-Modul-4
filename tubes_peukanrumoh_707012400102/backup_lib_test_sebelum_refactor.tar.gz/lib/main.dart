import 'package:flutter/material.dart';

import 'navigation/app_router.dart';
import 'navigation/app_routes.dart';
import 'theme/theme_controller.dart';

/// Titik masuk aplikasi Peukan Rumoh (demo navigasi DPPB).
///
/// Seluruh navigasi terdaftar di [AppRouter] dan [AppRoutes]:
/// - `initialRoute` memakai nama route, bukan widget `home`;
/// - `onGenerateRoute` memetakan semua nama route;
/// - `onUnknownRoute` menangkap nama route salah tulis agar aplikasi
///   tidak berhenti paksa.
void main() {
  runApp(const PeukanRumohApp());
}

class PeukanRumohApp extends StatelessWidget {
  const PeukanRumohApp({super.key});

  // Teal Peukan Rumoh dipakai sebagai warna seed (identitas dari DPPB).
  static const Color seedTeal = Color(0xFF11998E);

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: ThemeController.instance,
      builder: (context, _) {
        return MaterialApp(
          title: 'Peukan Rumoh',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(seedColor: seedTeal),
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            colorScheme: ColorScheme.fromSeed(
              seedColor: seedTeal,
              brightness: Brightness.dark,
            ),
          ),
          themeMode: ThemeController.instance.mode,
          initialRoute: AppRoutes.splash,
          onGenerateRoute: AppRouter.onGenerateRoute,
          onUnknownRoute: AppRouter.onUnknownRoute,
        );
      },
    );
  }
}
